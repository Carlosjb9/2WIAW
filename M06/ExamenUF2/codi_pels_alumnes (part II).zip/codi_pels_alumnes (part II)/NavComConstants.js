export const TIPUSNAVCOM = ["", "primari", "secundari"];
export const TIPUSWAYPOINT = ["", "planeta", "lluna", "asteroide"];
