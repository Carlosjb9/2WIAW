export function crearData(dataText) {
  const date = new Date(dataText);
  return date;
}
