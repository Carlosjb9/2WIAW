const DEPARTAMENTS = ["", "Comandament", "Armes", "Timó i navegació", "Enginyeria", "Ciència"];
const TIPUSNAUS = ["", "corbeta", "fragata", "destructor", "creuer", "acuirasat", "transport"];
const pathImatges = "imatges/";

