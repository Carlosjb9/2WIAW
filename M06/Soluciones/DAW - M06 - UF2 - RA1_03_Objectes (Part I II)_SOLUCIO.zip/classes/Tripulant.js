class Tripulant {
    id;
    nom;
    cognom;
    carrec;
    departamentId;
    actiu = true;
    nauId;
    personalDeDrassana = false;

    veureDades() {
        return this.nom + " " + this.cognom + " (ID: " + this.id + ")";
    }
}