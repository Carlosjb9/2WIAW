import { DEPARTAMENTS, pathImatges } from "./../PalasAteneaConstants.js";
import { PalasAtenaPerFormulariTripulants } from "./tripulantsInicialitzador.js";


window.addEventListener("load", carregarDadesTripulant);
window.addEventListener("load", crearLListaDesplegableDepartaments);
document.getElementById("botoGuardarDades").addEventListener("click", comprovarPsw);


function carregarDadesTripulant() {
    let tripulantId = sessionStorage.getItem("formulariTripulant_TripulantId");

    for (let tripulantTmp of PalasAtenaPerFormulariTripulants.tripulacio) {
        if (tripulantTmp.getId() == tripulantId) {
            document.getElementById("id").value = tripulantTmp.getId();
            document.getElementById("nom").value = tripulantTmp.getNom();
            document.getElementById("cognom").value = tripulantTmp.getCognom();
            document.getElementById("carrec").value = tripulantTmp.carrec;
            document.getElementById("departamentId").value = tripulantTmp.departamentId;
            document.getElementById("actiu").value = tripulantTmp.actiu;
            document.getElementById("imatge").src = pathImatges + tripulantTmp.imatge;
            document.getElementById("imatge").width = 128;
            document.getElementById("nauId").value = tripulantTmp.nauId;
            document.getElementById("personalDeDrassana").value = tripulantTmp.personalDeDrassana;
        }
    }
}


function crearLListaDesplegableDepartaments() {
    let llistaDepartaments = document.getElementById("llistaDepartaments");

    llistaDepartaments.length = 0;

    for (let i = 1; i < DEPARTAMENTS.length; i++) {
        let opcioNova = document.createElement("option");
        opcioNova.value = i;
        opcioNova.text = DEPARTAMENTS[i];

        if (i == document.getElementById("departamentId").value) {
            opcioNova.selected = true;
        }

        llistaDepartaments.appendChild(opcioNova);
    }
}


function comprovarPsw() {
    // Format del password: mínim 4 caràcters + mínim 1 majúscula + mínim 1 nº.

    let pswCorrecte = false;

    let psw = document.getElementById("psw").value;

    let patro = /.{4,}/g;
    if (psw.search(patro) != -1) {
        patro = /[A-Z]+/;

        if (psw.search(patro) != -1) {
            patro = /\d+/;

            if (psw.search(patro) != -1) {
                pswCorrecte = true;
            }
        }
    }

    if (pswCorrecte == false) {
        alert("Format del password: mínim 4 caràcters + mínim 1 majúscula + mínim 1 nº.");

        document.getElementById("psw").focus();
    } else {
        formulari.submit();
    }
}

