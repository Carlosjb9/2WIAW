const PI = 3.1416;
let figuresEnCanvas = [];


export function pintarEnCanvas(numForma) {
    console.log("pintarEnCanvas.numForma = " + numForma);

    let posXObjectiu = parseInt(document.getElementById("coordX").value);
    let posYObjectiu = parseInt(document.getElementById("coordY").value);


    let c = document.getElementById("canvasOnPintar");
    let ctx = c.getContext("2d");
    ctx.beginPath();        // Si no fem això i pintem una recta, independentment de que pintem si al final pintem un arc
                            // aquest s'unirà amb l'última recta pintada. A més a més, si pintem un arc seguit d'un altre,
                            // s'uniran.
                            // Mètode que crea un nou path i buida la llista de sub-path's.

    switch (numForma) {
        case "1":
            ctx.moveTo(posXObjectiu, posYObjectiu);         // Pos. inicial de la línia.
            let posXFinal = posXObjectiu + 100;
            let posYFinal = posYObjectiu + 100;
            ctx.lineTo(posXFinal, posYFinal);               // Pos. final de la línia.
            
            ctx.strokeStyle = "red";
            ctx.stroke();
            break;
            
        case "2":
            ctx.strokeRect(posXObjectiu, posYObjectiu, 50, 25);     // Creem el rectangle buit i el dibuixem.
            // ALERTA: DIBUIXEM AMB stroke() I COM QUE EN EL case "1" HI HA ctx.strokeStyle = "red" A LLAVORS
            // TOTHOM QUE IMPRIMEIXI AMB stroke() o strokeText()) A LLAVORS HO FARÀ EN COLOR VERMELL. 
            break;

        case "3":
            ctx.arc(posXObjectiu, posYObjectiu, 60, 0*PI, 1*PI, true);
            ctx.strokeStyle = "green";          // Evitem imprimir en vermell o negre (color per defecte) i pintem en verd.
            ctx.stroke();                       // Dibuixem l'arc.
            break;

        case "4":
            ctx.font = "30px Arial";
            ctx.fillText("Marte", posXObjectiu, posYObjectiu);          // Dibuixem el text.
            break;

        case "5":
            ctx.font = "30px Arial";
            ctx.strokeText("Marte", posXObjectiu, posYObjectiu);          // Dibuixem el text.
            break;    
            
        case "6":
            // Creem el degradat lineal (l'àrea del rectangle que farem servir, ojo que si no fem servir el principi del
            // rectangle a llavors l'omple amb el 1r color i si no fem servir part del final l'omple amb l'últim color):
            var grd = ctx.createLinearGradient(0,0,250,0);
            grd.addColorStop(0,"red");                  // Es pinta al principi
            // 1r paràmetre = el offset. Valor [0,1] = la posició del color. 0 = al principi del gradient i 1 al final.
            // 2n paràmetre = el color en que acaba.
            grd.addColorStop(0.17, "orange");           // Es pinta en la pos. que equival al 20% de la long. del gradient.
            grd.addColorStop(0.33, "yellow");
            grd.addColorStop(0.5,"green");
            grd.addColorStop(0.67,"blue");
            grd.addColorStop(0.84,"indigo");
            grd.addColorStop(1,"purple");
            ctx.fillStyle = grd;                        // Omplim amb el degradat:
            ctx.fillRect(0, 0, 250,100);
            break;   
            
        case "7":
            let elementImatge = document.createElement("IMG");
            elementImatge.setAttribute("src", "mcrn.jpg");
            ctx.drawImage(elementImatge, posXObjectiu, posYObjectiu, 89, 50);
            break;              
    
        default:
            break;
    }


    let figura = {
        numForma: "",
        posXObjectiu: "",
        posYObjectiu: ""
    }

    Object.preventExtensions(figura);     // D'aquesta manera evitem que ningú amplii l'objecte afegint/eliminant propietats i mètodes.

    figura.numForma = numForma;
    figura.posXObjectiu = posXObjectiu;
    figura.posYObjectiu = posYObjectiu;

    figuresEnCanvas.push(figura);

    crearLListaFiguresEnCanvas();
}


function crearLListaFiguresEnCanvas(){
    let llistaFigures = document.getElementById("llistaFigures");

    llistaFigures.length = 0;           // Esborrem la llista.

    for (let i = 0; i < figuresEnCanvas.length; i++) {
        let opcioNova = document.createElement("option");
        opcioNova.value = i;            // Fem que el value sigui l'index dins de l'array "figuresEnCanvas".
        opcioNova.text = figuresEnCanvas[i].numForma + " en coord. (" + figuresEnCanvas[i].posXObjectiu + ", " + figuresEnCanvas[i].posYObjectiu + ")";

        if (i == (figuresEnCanvas.length - 1)) {
            opcioNova.selected = true;
        }

        llistaFigures.appendChild(opcioNova);
    }
}


export function esborrarTotElCanvas() {
    let c = document.getElementById("canvasOnPintar");
    let ctx = c.getContext("2d");

    ctx.clearRect(0,0,800,500);         // Esborra tots els píxels que hi ha dins del rectangle determinat per
                                        // les coordenades passades (la més petita i la més gran del rectangle).
    ctx.beginPath();                    // D'aquesta manera el ctx es neteja i no s'enrecorda de les rectes i arcs fets.      
    
    figuresEnCanvas = [];

    crearLListaFiguresEnCanvas();
}


export function esborrarFiguraDelCanvas(index) {
    let figuresEnCanvasTmp = [];

    figuresEnCanvas.splice(index, 1);       // Esborra 1 element a partir de la pos. = index.
    figuresEnCanvasTmp = figuresEnCanvas;   // Això és perquè la funció "esborrarTotElCanvas()" executa "figuresEnCanvas = [];" .

    crearLListaFiguresEnCanvas();

    esborrarTotElCanvas();

    // Ara repintem el canvas amb totes les figures que queden en "figuresEnCanvas":
    // Recorrem "figuresEnCanvas" i per a cada entrada cridem a "pintarEnCanvas(numForma)"
    // però hem de ficar en els input type text "coordX" i "coordY" els valors de les
    // coordenades d'on vam fer click.

    for (let i = 0; i < figuresEnCanvasTmp.length; i++) {
        document.getElementById("coordX").value = figuresEnCanvasTmp[i].posXObjectiu;
        document.getElementById("coordY").value = figuresEnCanvasTmp[i].posYObjectiu;

        pintarEnCanvas(figuresEnCanvasTmp[i].numForma);
    }
}

