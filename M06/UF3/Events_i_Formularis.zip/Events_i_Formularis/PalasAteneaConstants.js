export const DEPARTAMENTS = ["", "Comandament", "Armes", "Timó i navegació", "Enginyeria", "Ciència"];
export const TIPUSNAUS = ["", "corbeta", "fragata", "destructor", "creuer", "acuirasat", "transport"];
export const pathImatges = "imatges/";

