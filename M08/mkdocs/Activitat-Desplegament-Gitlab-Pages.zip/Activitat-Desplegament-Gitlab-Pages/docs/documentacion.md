## Creació de l'entorn mkdocs

![Captura1](./images/captura1.png)

### Comprovar si està instal·lat Python

```
// Podrem veure la versió de python3, si no apareix res, cal instal·lar-lo
python3 --version

```

### Instal·lar Python (en cas de no tenir-lo instal·lat prèviament)

```
pip install python3
```

### Crear l'entorn mkdocs

```
python3 -m venv <nom de l'entorn>
```

### Activa l'entorno

```
cd <nom de l'entorn>
source bin/activate
```

### Instal·lar un tema per al mkdocs

```
pip install <nombre del tema>
```

### Creació del fitxer mkdocs.yml

```
site_name:  Carlos
theme:
name:  dracula
nav:
-  Indice:  index.md
-  Perros(html):  perros.html
-  Documentación:  documentacion.md
```

#### Explicació

```
El 'site_name' serveix per especificar el nom del lloc web.
El 'theme' especifica el nom del tema que ha d'estar instal·lat per funcionar.
Amb el 'nav' especifiques el menú de navegació. La estructura utilitzada és: "- TÍTOL: fitxer".

```

![Captura3](./images/captura3.png)

### Iniciar el servidor de forma local

```
mkdocs serve
```

### Crear els fitxers indicats al nav dins de la carpeta docs

### perros.html

```
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>¡Adopta a este adorable perro!</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f4f4f4;
      }
      .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      }
      h1,
      p {
        text-align: center;
      }
      img {
        display: block;
        margin: 0 auto;
        max-width: 100%;
        border-radius: 8px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>¡Adopta a este adorable perro!</h1>
      <p>
        Este perro necesita un hogar lleno de amor. ¡Es amigable, juguetón y
        leal!
      </p>
      <img src="images/perro.jpeg" alt="Foto del perro" />
      <p>
        Contacta con nosotros para más información sobre cómo adoptar a este
        dulce compañero.
      </p>
      <p>¡No esperes más para darle un hogar a este perro!</p>
    </div>
  </body>
</html>

```

### Creem la documentació

```
Aquest arxiu que estàs llegint (docs/documentacio.md)

```

### Crear l'arxiu .gitlab-ci.yml

```
image:
 name:  python:3.8-buster
stages:
 -  docs
pages:
 stage:  docs
 script:
 -  pip  install  mkdocs
 -  pip  install  mkdocs-dracula-theme
 -  mkdocs  build
 -  cp  -r  site  public
 artifacts:
 paths:
 -  public
```

#### Explicació

```
El 'name' de la imatge és: la imatge del contenidor Docker.
Els 'stages' defineixen un esdeveniment del projecte, en aquest cas el nomenem "docs".
Les 'pages' indiquen la tasca que el gitlab CI/CD executarà.
L'etapa 'docs' indica que la tasca pages s'executarà en l'esdeveniment docs.
La secció 'script' és una successió de comandes que s'executaran:

    -   'pip install mkdocs' instal·la el mkdocs.
    -   'pip install mkdocs-material' instal·la el tema material del mkdocs.
    -   'mkdocs build' construeix el lloc web.
    -   'cp -r site public' copia el contingut del mkdocs a public, és a dir, al directori que contindrà la informació del nostre lloc web.
    Els 'artifacts' serveixen per conservar el projecte; amb el 'path' definim el que volem conservar, el 'public', que conté la informació del nostre lloc web.

```
